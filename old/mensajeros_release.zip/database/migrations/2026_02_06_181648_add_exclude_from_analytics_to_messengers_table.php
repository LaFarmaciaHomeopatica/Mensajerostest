<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('messengers', function (Blueprint $table) {
            $table->boolean('exclude_from_analytics')->default(false)->after('is_active');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('messengers', function (Blueprint $table) {
            $table->dropColumn('exclude_from_analytics');
        });
    }
};
