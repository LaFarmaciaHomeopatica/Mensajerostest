import React, { forwardRef, useRef } from 'react';

export default forwardRef(function SelectInput({ className = '', children, ...props }, ref) {
    const input = ref ? ref : useRef();

    return (
        <div className="relative">
            <select
                {...props}
                className={
                    'w-full border-slate-200 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 text-sm rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all py-2.5 px-4 shadow-sm appearance-none bg-[url(\'data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20fill%3D%22none%22%20viewBox%3D%220%200%2024%2024%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222%22%3E%3Cpath%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%20d%3D%22M19%209l-7%207-7-7%22%2F%3E%3C%2Fsvg%3E\')] bg-[length:1.25rem_1.25rem] bg-[right_0.75rem_center] bg-no-repeat ' +
                    className
                }
                ref={input}
            >
                {children}
            </select>
        </div>
    );
});
